var searchData=
[
  ['native_20access',['Native access',['../group__native.html',1,'']]]
];
